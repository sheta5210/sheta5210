/**
 * Theme: Ubold Admin Template
 * Author: Coderthemes
 * Form Advanced
 */


jQuery(document).ready(function () {


    // Select2
    $(".select2").select2();

});
